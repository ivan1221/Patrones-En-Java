package com.ejemplo.patron.abstractfactory.main;

import java.util.Scanner;

import com.ejemplo.patron.abstractfactory.Automovil;
import com.ejemplo.patron.abstractfactory.FabricaVeiculo;
import com.ejemplo.patron.abstractfactory.FabricaVeiculoElectricidad;
import com.ejemplo.patron.abstractfactory.FabricaVeiculoGasolina;
import com.ejemplo.patron.abstractfactory.Scooter;

public class Catalogo {
	
	public static int nAutos = 3;
	public static int nScooter = 2;
	
	public static void imprimirParametro(String name, String value) {
		System.out.println("Param "+name+": " + value);
	}

	public static void main(String[] args) {
		System.out.println("com.ejemplo.patron.abstractfactory clase Main...");
		Scanner reader = new Scanner(System.in);
		
		int opcionTipoVeiculo = 0;
		int opcionTipoCombustible = 0;
		
		FabricaVeiculo fabricaVeiculo;
		
		imprimirParametro("opcionTipoVeiculo", ""+opcionTipoVeiculo);
		imprimirParametro("opcionTipoCombustible", ""+opcionTipoCombustible);
		
		Automovil[] autos = new Automovil[nAutos];
		Scooter[] scooters = new Scooter[nScooter];
		System.out.println("Deseas utilizar veiculo de Gasolina[1]  o veiculo electrico [2]");
		String seleccion = reader.next();
		if (seleccion.equals("1")) {
			fabricaVeiculo = new FabricaVeiculoGasolina();
		}else{
			fabricaVeiculo = new FabricaVeiculoElectricidad();
		}
		System.out.println("llenar Arreglo automoviles ");
		for(int index= 0; index< nAutos; index++){
			autos[index] = fabricaVeiculo.creaAutomovil("Standar", "Roja", 6+index, 6.3);
		}
		System.out.println("llenar Arreglo scooters ");
		for(int index= 0; index< nScooter; index++){
			scooters[index] = fabricaVeiculo.creaScooter("Standar", "Roja", 6+index);
		}
		System.out.println("-------Imprimiendo Arreglo automoviles------- ");
		for (Automovil auto : autos) {
			auto.mostrarCaracteristicas();
		}
		System.out.println("-------Imprimiendo Arreglo scooters------- ");
		for (Scooter scooter : scooters) {
			scooter.mostrarCaracteristicas();
		}
		System.out.println("--------------- THE END ---------------");

	}

}
