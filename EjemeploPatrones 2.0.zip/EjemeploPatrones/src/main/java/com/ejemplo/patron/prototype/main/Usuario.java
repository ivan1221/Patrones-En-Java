package com.ejemplo.patron.prototype.main;

import com.ejemplo.patron.prototype.CertificadoSecion;
import com.ejemplo.patron.prototype.DocumentacionCliente;
import com.ejemplo.patron.prototype.DocumentacionEnBlanco;
import com.ejemplo.patron.prototype.OrdenDePedido;
import com.ejemplo.patron.prototype.SolicitudMatriculacion;

public class Usuario {
	
	
	public static void main(String[] args){
		System.out.println("com.ejemplo.patron.prototype.main");
		System.out.println("-------------------- START MAIN------------------");

		DocumentacionEnBlanco documentacionblanco = DocumentacionEnBlanco.Instance();
		documentacionblanco.incluye(new OrdenDePedido());
		documentacionblanco.incluye(new SolicitudMatriculacion());
		documentacionblanco.incluye(new CertificadoSecion());
		//creacion de documentacion nueva para los clientes
		DocumentacionCliente documentacionCliente1 = new DocumentacionCliente("Pedro");
		DocumentacionCliente documentacionCliente2 = new DocumentacionCliente("Mauro Biglio");
		documentacionCliente1.visualizar();
		documentacionCliente2.visualizar();
		System.out.println("-------------------- THEN END MAIN------------------");

	}

}
