package com.ejemplo.patron.adapter.main;

import com.ejemplo.patron.adapter.Documento;
import com.ejemplo.patron.adapter.DocumentoHTML;
import com.ejemplo.patron.adapter.DocumentoPdf;

public class ServidorWeb {

	public static void main(String[] args) {
		System.out.println("com.ejemplo.patron.adapter.main");
		System.out.println("Iniciando prueba del patron Adapter");
		Documento documento1, documento2;
		System.out.println("-------- Doc 1----------");
		documento1 = new DocumentoHTML();
		documento1.setContenido("Hello..");
		documento1.dibuja();
		System.out.println("-------- Doc 2----------");
		documento2 = new DocumentoPdf();
		documento2.setContenido("Hola..");
		documento2.dibuja();
		System.out.println("Finalizando prueba del patron Adapter");
	}

}
