package com.ejemplo.patron.prototype;

public class OrdenDePedido extends Documento{

	@Override
	public void imprime() {
		System.out.println("Muestra la orden del pedido: "+ contenido);
	}

	@Override
	public void visualiza() {
		System.out.println("imprime la orden del pedido: "+ contenido);
	}

}
