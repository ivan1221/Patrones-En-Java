package com.ejemplo.patron.builder;

public class Vendedor {

	protected ConstructorDocumentacionVehiculo constructor;

	public Vendedor(ConstructorDocumentacionVehiculo constructor) {

		this.constructor = constructor;
	}
	
	public Documentacion construye(String nombreCliente){
		constructor.costruyendoSolicitudPedido(nombreCliente);
		constructor.costruyendoSolicitudMatriculacion(nombreCliente);
		Documentacion doc = constructor.resultado();
		return doc;	
	}

}
