package com.ejemplo.patron.singleton.main;

import com.ejemplo.patron.singleton.Comercial;

public class ComercialTest {
	
	
	public static void main(String[] args){
		System.out.println("com.ejemplo.patron.singleton.main");
		System.out.println("Iniciando prueba patron Singleton..");
		Comercial elComercial = Comercial.instance();
		elComercial.setNombre("Silvano");
		elComercial.setDireccion("Calle Primera 1");
		elComercial.setEmail("prueba@outlook.com");
		System.out.println("terminando setear datos..");
		visualizar();
		System.out.println("Terminando prueba patron Singleton..");
	}
	
	public static void visualizar(){
		Comercial elComercial = Comercial.instance();
		elComercial.visualizar();
	}

}
