package com.ejemplo.patron.bridge;

public class FormularioMatriculacionEspana extends FormularioMatriculacion{

	public FormularioMatriculacionEspana(FormularioImpl implementacion) {
		super(implementacion);
	}

	@Override
	protected boolean controlZona(String matriculacion) {
		return matriculacion.length() == 7;
	}

}
