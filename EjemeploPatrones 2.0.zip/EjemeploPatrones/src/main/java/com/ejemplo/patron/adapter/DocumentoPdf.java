package com.ejemplo.patron.adapter;

public class DocumentoPdf implements Documento{
	
	protected ComponentePDF herramientaPdf = new ComponentePDF();

	@Override
	public void setContenido(String contenido) {
    herramientaPdf.pdfFijaContenido(contenido);		
	}

	@Override
	public void dibuja() {
		herramientaPdf.preparaVisualizacion();
		herramientaPdf.pdfRenfresca();
		herramientaPdf.pdfFinalizaVisualizacion();
	}

	@Override
	public void imprime() {
		herramientaPdf.pdfEnviaImpresora();
	}

}
