package com.ejemplo.patron.abstractfactory;

public class ScooterGasolina extends Scooter {

	public ScooterGasolina(String modelo, String color, int potencia) {
		super(modelo, color, potencia);
	}

	@Override
	public void mostrarCaracteristicas() {
		System.out.println("Scooter Gasolina de modelo: " + modelo + " color: " + color + " potencia: " + potencia);
	}

}
