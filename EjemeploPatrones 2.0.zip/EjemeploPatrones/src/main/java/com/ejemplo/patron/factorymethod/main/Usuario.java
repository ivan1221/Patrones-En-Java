package com.ejemplo.patron.factorymethod.main;

import com.ejemplo.patron.factorymethod.Cliente;
import com.ejemplo.patron.factorymethod.ClienteContado;
import com.ejemplo.patron.factorymethod.ClienteCredito;

public class Usuario {
	
	public static void main(String... args){
		System.out.println("com.ejemplo.patron.factorymethod.main");
		System.out.println("-------------------- START MAIN------------------");
		Cliente cliente;
		cliente = new ClienteContado();
		cliente.nuevoPedido(2000);
		cliente.nuevoPedido(10000);
		cliente = new ClienteCredito();
		cliente.nuevoPedido(2000);
		cliente.nuevoPedido(10000);
		System.out.println("-------------------- THE END MAIN------------------");
	}

}
