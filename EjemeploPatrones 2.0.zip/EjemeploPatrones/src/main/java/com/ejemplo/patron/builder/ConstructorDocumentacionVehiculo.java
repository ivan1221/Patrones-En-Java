package com.ejemplo.patron.builder;

public abstract class ConstructorDocumentacionVehiculo {
	
	protected Documentacion documentacion;
	
	public abstract void costruyendoSolicitudPedido(String nombreCliente);
	
	public abstract void costruyendoSolicitudMatriculacion(String nombreSolicitante);
	
	public Documentacion resultado(){
		return documentacion;
	}

}
