package com.ejemplo.patron.adapter;

public class ComponentePDF {

	protected String contenido;

	public void pdfFijaContenido(String contenido) {
		this.contenido = contenido;
	}

	public void preparaVisualizacion() {
		System.out.println("Visualiza PDF: comienzo ");
	}

	public void pdfRenfresca() {
		System.out.println("Visualiza contenido PDF: " + contenido);
	}

	public void pdfFinalizaVisualizacion() {
		System.out.println("Visualiza PDF Fin..");
	}

	public void pdfEnviaImpresora() {
		System.out.println("Impresion PDF :" + contenido);
	}

}
