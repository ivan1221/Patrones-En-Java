package com.ejemplo.patron.bridge;

public abstract class FormularioMatriculacion {

	protected String contenido;

	protected FormularioImpl implementacion;

	public FormularioMatriculacion(FormularioImpl implementacion) {
		this.implementacion = implementacion;
	}

	public void visualizar() {
		implementacion.dibujaTexto("numero de matriculacion existente: ");
	}

	public void generarDocumento() {
		implementacion.dibujaTexto("solicitud de matriculacion: ");
		implementacion.dibujaTexto("numero de matriculacion: " + contenido);
	}

	public Boolean administraZona() {
		this.contenido = implementacion.administracionZonaIndicada();
		return this.controlZona(contenido);
	}

	protected abstract boolean controlZona(String matriculacion);
	
}
