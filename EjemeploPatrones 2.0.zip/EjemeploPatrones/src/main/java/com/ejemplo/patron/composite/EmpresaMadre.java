package com.ejemplo.patron.composite;

import java.util.ArrayList;
import java.util.List;

public class EmpresaMadre  extends Empresa{
	
	protected List<Empresa> filiales = new ArrayList<>();

	@Override
	public double calculaCosteMantenimiento() {
		double coste = 0.0;
		for (Empresa empresa : filiales) {
			coste = coste + empresa.calculaCosteMantenimiento();
		}
		return coste + nVehiculos* costeUnitarioVehiculo;
	}

	@Override
	public boolean agregaFilial(Empresa empresaFilia) {
		return filiales.add(empresaFilia);
	}

}
