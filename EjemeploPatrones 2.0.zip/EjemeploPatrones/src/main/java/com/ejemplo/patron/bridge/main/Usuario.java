package com.ejemplo.patron.bridge.main;

import com.ejemplo.patron.bridge.FormAppletImpl;
import com.ejemplo.patron.bridge.FormHtmlImpl;
import com.ejemplo.patron.bridge.FormularioMatriculacionEspana;
import com.ejemplo.patron.bridge.FormularioMatriculacionPortugal;

public class Usuario {
	
	
	public static void main(String args[]){
		System.out.println("com.ejemplo.patron.bridge.main");
		System.out.println("------------FormularioMatriculacionPortugal BEGIN------------");
		FormularioMatriculacionPortugal formula1 = new FormularioMatriculacionPortugal(new FormHtmlImpl());
		formula1.visualizar();
		if (formula1.administraZona()) {
			formula1.generarDocumento();
		}
		System.out.println("------------FormularioMatriculacionPortugal END------------");
		System.out.println("------------FormularioMatriculacionEspana BEGIN------------");
		FormularioMatriculacionEspana formula2 = new FormularioMatriculacionEspana(new FormAppletImpl());
		formula2.visualizar();
		if (formula2.administraZona()) {
			formula2.generarDocumento();
		}
		System.out.println("------------FormularioMatriculacionEspana END------------");
	}

}
