package com.ejemplo.patron.bridge;

public class FormularioMatriculacionPortugal extends FormularioMatriculacion {

	public FormularioMatriculacionPortugal(FormularioImpl implementacion) {
		super(implementacion);
	}

	@Override
	protected boolean controlZona(String matriculacion) {
		return matriculacion.length()==6;
	}

}
