package com.ejemplo.patron.builder;

public class DocumentoPdf extends Documentacion {

	@Override
	public void agregarDocumento(String documento) {
		if (documento.startsWith("<html>")) {
			contenido.add(documento);
		}
	}

	@Override
	public void imprimir() {
		System.out.println("Documentacion en HTML");
		for (String content : contenido) {
			System.out.println(content);
		}
	}

}
