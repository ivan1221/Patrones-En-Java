package com.ejemplo.patron.facade;

import java.util.ArrayList;
import java.util.List;

public class ComponenteCatalogo implements Catalogo {
	
	protected Object[] descripcionVeihiculos = { "Berlina 5 puertas " , 6000,
			                                      "Compacto 3 Puertas", 4000,
			                                      "Break 5 puertas"  , 4000,
			                                      "Linux 1 puertas"  , 7000,
			                                      "Windows 2 puertas"  , 3000,
			                                      "Mac 8 puertas"  , 10000,};

	@Override
	public List<String> buscaVeihiculos(int PrecioMin, int PrecioMax) {
		int indice, tamano;
		List<String> resultado = new ArrayList<>();
		tamano = descripcionVeihiculos.length / 2;
		for(indice = 0 ; indice<tamano; indice++ ){
			int precio = (Integer)descripcionVeihiculos[2*indice+1];
			if ((precio >= PrecioMin) && (precio <= PrecioMax)) {
				resultado.add((String) descripcionVeihiculos[2*indice]);
			}
		}
		return resultado;
	}

}
