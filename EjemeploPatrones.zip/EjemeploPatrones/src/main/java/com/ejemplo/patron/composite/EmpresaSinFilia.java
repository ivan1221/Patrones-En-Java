package com.ejemplo.patron.composite;

public class EmpresaSinFilia extends Empresa {

	@Override
	public double calculaCosteMantenimiento() {
		return nVehiculos* Empresa.costeUnitarioVehiculo;
	}

	@Override
	public boolean agregaFilial(Empresa empresaFilia) {
		return false;
	}

}
