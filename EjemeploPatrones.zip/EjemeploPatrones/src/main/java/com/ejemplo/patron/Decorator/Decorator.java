package com.ejemplo.patron.Decorator;

public abstract class Decorator implements ComponenteGraficoVeiculo{

	protected ComponenteGraficoVeiculo componente;
	
	public Decorator(ComponenteGraficoVeiculo componente){
		this.componente = componente;
	}
	
	public void visualiza(){
		componente.visualiza();
	}
	
}
