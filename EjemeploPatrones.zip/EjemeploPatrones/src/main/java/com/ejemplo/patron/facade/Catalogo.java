package com.ejemplo.patron.facade;

import java.util.List;

public interface Catalogo {
	
	List<String> buscaVeihiculos(int PrecioMin, int PrecioMax);

}
