package com.ejemplo.patron.Decorator;

public class ModeloDecorador extends Decorator{

	public ModeloDecorador(ComponenteGraficoVeiculo componente) {
		super(componente);
	}
	
	protected void visualizarInformacionTecnica(){
		System.out.println("Informacion tecnica del modelo.");
	}
	
	public void visualiza(){
		super.visualiza();
		this.visualizarInformacionTecnica();
	}

}
