package com.ejemplo.patron.abstractfactory;

public interface FabricaVeiculo {
	
	/**
	 * 
	 * @param modelo
	 * @param color
	 * @param potencia
	 * @param espacio
	 * @return
	 */
	Automovil creaAutomovil(String modelo, String color, int potencia, double espacio);
	
	/**
	 * 
	 * @param modelo
	 * @param color
	 * @param potencia
	 * @return
	 */
	Scooter creaScooter(String modelo, String color, int potencia);

}
