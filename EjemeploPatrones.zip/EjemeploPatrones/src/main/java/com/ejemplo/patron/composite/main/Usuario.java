package com.ejemplo.patron.composite.main;

import com.ejemplo.patron.composite.Empresa;
import com.ejemplo.patron.composite.EmpresaMadre;
import com.ejemplo.patron.composite.EmpresaSinFilia;

public class Usuario {
	
	public static void main(String... args){
		
		System.out.println("com.ejemplo.patron.composite.main");
		Empresa empresa1 = new EmpresaSinFilia();
		empresa1.agregarVehiculo();
		Empresa empresa2 = new EmpresaSinFilia();
		empresa2.agregarVehiculo();
		empresa2.agregarVehiculo();
		
		Empresa grupo = new EmpresaMadre();
		grupo.agregaFilial(empresa1);
		grupo.agregaFilial(empresa2);
		grupo.agregarVehiculo();
		
		System.out.println("coste de mantenimineto total del grupo: "+ grupo.calculaCosteMantenimiento());
		
	}

}
