package com.ejemplo.patron.facade;

import java.util.List;

public interface WebServiceAuto {
	
	String documento(int indice);
	
	List<String> buscarVeihiculos(int precioMedio, int desviacionMax);

}
