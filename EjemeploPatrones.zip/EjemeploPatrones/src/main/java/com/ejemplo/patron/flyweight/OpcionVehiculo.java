package com.ejemplo.patron.flyweight;

public class OpcionVehiculo {
	
	protected String nombre;
	protected String descripcion;
	protected int precioEstandar;
	public OpcionVehiculo(String nombre) {
		super();
		this.nombre = nombre;
		this.descripcion = "descripcion de "+ nombre;
		this.precioEstandar = 100;
	}
	
	public void visualiza(int precioVenta){
		System.out.println("Opcion");
		System.out.println("Nombre : "+ nombre);
		System.out.println(descripcion);
		System.out.println("Precio estandar: "+ precioEstandar);
		System.out.println("Precio de venta "+ precioVenta);
		
	}

}
