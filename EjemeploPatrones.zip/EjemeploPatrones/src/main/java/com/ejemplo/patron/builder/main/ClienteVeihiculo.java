package com.ejemplo.patron.builder.main;

import java.util.Scanner;

import com.ejemplo.patron.builder.ConstructorDocumentacionVehiculo;
import com.ejemplo.patron.builder.ConstructorDocumentacionVehiculoPdf;
import com.ejemplo.patron.builder.ConstructorDocumentacionVeihiculoHtml;
import com.ejemplo.patron.builder.Documentacion;
import com.ejemplo.patron.builder.Vendedor;

public class ClienteVeihiculo {

	public static void main(String[] args) {
		System.out.println("com.ejemplo.patron.builder.main");
		System.out.println("-------------------- START MAIN------------------");
		Scanner scan = new Scanner(System.in);
		ConstructorDocumentacionVehiculo constructorVeihiculo;
		System.out.println("Desea generar documentacion HTML (1) o desea generar Documentacion PDF(2)..");
		String seleccion = scan.next();
		if (seleccion.equals("1")) {
			constructorVeihiculo = new ConstructorDocumentacionVeihiculoHtml();
		}else{
			constructorVeihiculo = new ConstructorDocumentacionVehiculoPdf();
		}
		Vendedor vendedor = new Vendedor(constructorVeihiculo);
		Documentacion doc = vendedor.construye("Mario");
		doc.imprimir();
		System.out.println("-------------Fin ----------");

	}

}
