package com.ejemplo.patron.factorymethod;

public class PedidoCredito extends Pedido{

	public PedidoCredito(double importe) {
		super(importe);
	}

	@Override
	public boolean valida() {
		// TODO Auto-generated method stub
		return (importe >= 1000.0) && (importe <= 5000.0);
	}

	@Override
	public void paga() {
		String paga= "El pago del pedido a credito con importe "+ importe+" se a realizado con exito.";
		System.out.println(paga);	
	}

}
