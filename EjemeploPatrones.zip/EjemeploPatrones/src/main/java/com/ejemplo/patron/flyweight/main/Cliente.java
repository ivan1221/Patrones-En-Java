package com.ejemplo.patron.flyweight.main;

import com.ejemplo.patron.flyweight.FabricaOpcion;
import com.ejemplo.patron.flyweight.VehiculoSolicitado;

public class Cliente {
	
	
	public static void main(String[] args){
		System.out.println("com.ejemplo.patron.flyweight.main");
		FabricaOpcion fabrica = new FabricaOpcion();
		VehiculoSolicitado vehiculo = new VehiculoSolicitado();
		vehiculo.agregarOpciones("air Bag", 80, fabrica);
		vehiculo.agregarOpciones("faros electricos", 85, fabrica);
		vehiculo.mostrarOpciones();
	} 

}
