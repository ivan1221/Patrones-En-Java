package com.ejemplo.patron.prototype;

public class CertificadoSecion extends Documento{

	@Override
	public void imprime() {
		System.out.println("Muestra la Certificacion de cesion: "+ contenido);
	}

	@Override
	public void visualiza() {
		System.out.println("Imprime la Certificacion de cesion: "+ contenido);
	}

}
