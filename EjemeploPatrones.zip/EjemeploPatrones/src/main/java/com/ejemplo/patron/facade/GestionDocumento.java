package com.ejemplo.patron.facade;

public interface GestionDocumento{
	
	String documento(int indice);

}
