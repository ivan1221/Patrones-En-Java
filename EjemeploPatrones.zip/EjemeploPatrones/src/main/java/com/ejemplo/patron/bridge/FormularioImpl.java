package com.ejemplo.patron.bridge;

public interface FormularioImpl {
	
	void dibujaTexto(String texto);
	
	String administracionZonaIndicada();

}
