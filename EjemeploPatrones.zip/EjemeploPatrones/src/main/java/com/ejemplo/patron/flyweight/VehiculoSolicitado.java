package com.ejemplo.patron.flyweight;

import java.util.ArrayList;
import java.util.List;

public class VehiculoSolicitado {
	
	protected List<OpcionVehiculo> opciones = new ArrayList<>();
	protected List<Integer> precioDeVentaOpciones = new ArrayList<>();	

	public void agregarOpciones(String nombre, int precioVenta, FabricaOpcion fabrica){
		opciones.add(fabrica.getOption(nombre));
		precioDeVentaOpciones.add(precioVenta);
	}
	
	public void mostrarOpciones(){
		int indice, tamano;
		tamano = opciones.size();
		for ( indice = 0; indice < tamano; indice++) {
			opciones.get(indice).visualiza(precioDeVentaOpciones.get(indice));
			System.out.println("---");
		}
	}
}
