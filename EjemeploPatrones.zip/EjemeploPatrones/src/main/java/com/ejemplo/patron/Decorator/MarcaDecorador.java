package com.ejemplo.patron.Decorator;

public class MarcaDecorador extends Decorator {

	public MarcaDecorador(ComponenteGraficoVeiculo componente) {
		super(componente);
	}
	
	protected void visualizLogo(){
		System.out.println("Logotipo de la marca");
	}
	
	public void visualizar(){
		super.visualiza();
		this.visualizLogo();
	}

}
