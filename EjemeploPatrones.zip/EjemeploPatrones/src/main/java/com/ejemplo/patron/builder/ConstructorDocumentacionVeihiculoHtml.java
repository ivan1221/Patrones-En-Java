package com.ejemplo.patron.builder;

public class ConstructorDocumentacionVeihiculoHtml extends ConstructorDocumentacionVehiculo {

	public ConstructorDocumentacionVeihiculoHtml(){
		documentacion = new DocumentacionHtml();
	}
	
	@Override
	public void costruyendoSolicitudPedido(String nombreCliente) {
		String documento;
		documento = "<html> solicitud Pedido Cliente "+ nombreCliente+ "</html>";
		documentacion.agregarDocumento(documento);
	}

	@Override
	public void costruyendoSolicitudMatriculacion(String nombreSolicitante) {
		String documento;
		documento = "<html> solicitud Matriculacion Solicitante "+ nombreSolicitante+ "</html>";
		documentacion.agregarDocumento(documento);
		
	}

}
