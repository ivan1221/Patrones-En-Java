package com.ejemplo.patron.adapter;

public interface Documento {
	
	void setContenido(String contenido);
	void dibuja();
	void imprime();
	
}
