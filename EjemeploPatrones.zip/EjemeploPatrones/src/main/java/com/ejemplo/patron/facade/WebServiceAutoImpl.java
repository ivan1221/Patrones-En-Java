package com.ejemplo.patron.facade;

import java.util.List;

public class WebServiceAutoImpl implements WebServiceAuto{
	
	
	protected Catalogo catalogo= new ComponenteCatalogo(); 
	protected GestionDocumento gestionDocumento = new ComponenteGestionDocumento();

	@Override
	public String documento(int indice) {
		return gestionDocumento.documento(indice);
	}

	@Override
	public List<String> buscarVeihiculos(int precioMedio, int desviacionMax) {
		return catalogo.buscaVeihiculos(precioMedio - desviacionMax, precioMedio+ desviacionMax);
	}

}
