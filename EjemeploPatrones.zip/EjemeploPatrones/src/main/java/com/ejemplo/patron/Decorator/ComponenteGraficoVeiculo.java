package com.ejemplo.patron.Decorator;

public interface ComponenteGraficoVeiculo {
	
	void visualiza();

}
