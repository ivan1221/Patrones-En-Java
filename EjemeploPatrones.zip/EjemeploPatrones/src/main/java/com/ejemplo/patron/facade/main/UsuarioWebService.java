package com.ejemplo.patron.facade.main;

import java.util.List;

import com.ejemplo.patron.facade.WebServiceAuto;
import com.ejemplo.patron.facade.WebServiceAutoImpl;

public class UsuarioWebService {
	
	
	public static void main(String args[]){
		System.out.println("com.ejemplo.patron.facade.main");
		WebServiceAuto webServiceAuto = new WebServiceAutoImpl();
		System.out.println(webServiceAuto.documento(0));
		System.out.println(webServiceAuto.documento(1));
		List<String> resultado = webServiceAuto.buscarVeihiculos(6000, 1000);
		if (resultado.size() >0) {
			System.out.println("Vehiculo cuyo precio esta comprendido entre 5000 y 7000 ");
			resultado.forEach(item ->{
				System.out.println(" "+ resultado);
			});
		}
		System.out.println("*-------------- END ------------*");
	}

}
