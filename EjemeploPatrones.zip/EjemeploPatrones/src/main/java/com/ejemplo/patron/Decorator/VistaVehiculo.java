package com.ejemplo.patron.Decorator;

public class VistaVehiculo implements ComponenteGraficoVeiculo {

	@Override
	public void visualiza() {
		System.out.println("Visualizacion del vehiculo.");
	}

}
