package com.ejemplo.patron.builder;

public class ConstructorDocumentacionVehiculoPdf extends ConstructorDocumentacionVehiculo {

	@Override
	public void costruyendoSolicitudPedido(String nombreCliente) {
		String documento;
		documento = "<pdf> solicitud Pedido Cliente "+ nombreCliente+ "</pdf>";
		documentacion.agregarDocumento(documento);
	}

	@Override
	public void costruyendoSolicitudMatriculacion(String nombreSolicitante) {
		String documento;
		documento = "<pdf> solicitud Matriculacion Solicitante "+ nombreSolicitante+ "</pdf>";
		documentacion.agregarDocumento(documento);
		
	}

}
