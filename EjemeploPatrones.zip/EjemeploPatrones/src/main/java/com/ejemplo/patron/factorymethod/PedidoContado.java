package com.ejemplo.patron.factorymethod;

public class PedidoContado extends Pedido {

	public PedidoContado(double importe) {
		super(importe);
	}

	@Override
	public boolean valida() {
		return true;
	}

	@Override
	public void paga() {
		String paga= "El pago del pedido con importe "+ importe+" se a realizado con exito.";
		System.out.println(paga);
	}

}
