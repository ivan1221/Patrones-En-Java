package com.ejemplo.patron.Decorator.main;

import com.ejemplo.patron.Decorator.MarcaDecorador;
import com.ejemplo.patron.Decorator.ModeloDecorador;
import com.ejemplo.patron.Decorator.VistaVehiculo;

public class VistaCatalogo {
	
	public static void main(String args[]){
		System.out.println("com.ejemplo.patron.Decorator.main");
		VistaVehiculo vistaVeiculo = new VistaVehiculo();
		ModeloDecorador modeloDecorador = new ModeloDecorador(vistaVeiculo);
		MarcaDecorador marcaDecorador = new MarcaDecorador(modeloDecorador);
		marcaDecorador.visualizar();
		System.out.println("*------------End -------------*");
	}

}
