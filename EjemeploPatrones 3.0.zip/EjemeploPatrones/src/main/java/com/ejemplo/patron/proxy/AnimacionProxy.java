package com.ejemplo.patron.proxy;

public class AnimacionProxy implements Animacion{
	
	protected Video video = null;
	protected String foto = "Mostrar la foto..";

	@Override
	public void dibuja() {
		
		if (video != null) {
			video.dibuja();
		}else{
			dibuja(foto);
		}
		
	}

	@Override
	public void click() {
		if (video == null) {
			video = new Video();
			video.carga();
		}
		video.reproduce();
	}
	
	public void dibuja(String foto){
		System.out.println(foto);
	}

}
