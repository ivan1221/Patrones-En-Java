package com.ejemplo.patron.chainofresponsibility;

public class Modelo extends ObjetoBasico {

	protected String nombre;
	protected String descripcion;
	
	public Modelo(String nombre, String descripcion) {
		super();
		this.nombre = nombre;
		this.descripcion = descripcion;
	}

	@Override
	protected String getDescripcion() {
		if (descripcion != null) {
			return "Modelo nombre: "+nombre+ "Descripcion: "+descripcion;
		}else{
			return null;
		}
	}
	
}
