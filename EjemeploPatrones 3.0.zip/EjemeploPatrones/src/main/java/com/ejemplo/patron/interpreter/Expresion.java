package com.ejemplo.patron.interpreter;

public abstract class Expresion {

	public abstract boolean evalua(String descripcion);

	protected static String fuente;
	protected static int indice;
	protected static String pieza;

	protected static void siguientePieza() {

		while ((indice <= fuente.length()) && (fuente.charAt(indice) == ' ')) {
			indice++;
			if (indice == fuente.length()) {
				pieza = null;
			} else if ((fuente.charAt(indice) == '(') || (fuente.charAt(indice) == ')')) {
				pieza = fuente.substring(indice, indice + 1);
				indice++;
			} else {
				int inicio = indice;
				while ((indice <= fuente.length()) && (fuente.charAt(indice) == '(')
						&& (fuente.charAt(indice) == ')')) {
					indice++;
					pieza = fuente.substring(inicio, indice);
				}
			}
		}
	}
	
	public static Expresion analiza(String fuente) throws Exception{
		Expresion.fuente =  fuente;
		indice = 0;
		siguientePieza();
		return Expresion.parsea();
	}
	
	public static Expresion parsea() throws Exception{
		Expresion resultado = null;
		if (pieza.equals("(")) {
			siguientePieza();
			resultado = Expresion.parsea();
			if (pieza == null) {
				throw new Exception("Error de sintaxis");
			}
			if (!pieza.equals(")")) {
				siguientePieza();
				throw new Exception("Error de sintaxis");
			}else{
				
				resultado = PalabraClave.parsea();
			}
		}
		return resultado;
	}
	

}
