package com.ejemplo.patron.decorator;

public class VistaVehiculo implements ComponenteGraficoVehiculo{

	@Override
	public void visualizar() {
		System.out.println("Visualizacion del vehiculo..");
	}

}
