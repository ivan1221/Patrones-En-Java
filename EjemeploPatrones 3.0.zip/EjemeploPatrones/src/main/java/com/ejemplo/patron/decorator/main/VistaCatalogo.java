package com.ejemplo.patron.decorator.main;

import com.ejemplo.patron.decorator.MarcaDecorador;
import com.ejemplo.patron.decorator.ModeloDecorador;
import com.ejemplo.patron.decorator.VistaVehiculo;

public class VistaCatalogo {

	public static void main(String[] args) {
		System.out.println("------- BEGIN *com.ejemplo.patron.decorator.main*---------");
		VistaVehiculo vistaVehiculo = new VistaVehiculo();
		ModeloDecorador modeloDecorador = new ModeloDecorador(vistaVehiculo);
		MarcaDecorador marcaDecorador = new MarcaDecorador(modeloDecorador);
		marcaDecorador.visualiza();
		System.out.println("---------END *com.ejemplo.patron.decorator.main*---------");
	}

}
