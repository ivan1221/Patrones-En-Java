package com.ejemplo.patron.command.main;

import com.ejemplo.patron.command.Catalogo;
import com.ejemplo.patron.command.SolicitudRebaja;
import com.ejemplo.patron.command.Vehiculo;

public class Usuario {
		
	public static void main(String args[]){
		
		System.out.println("com.ejemplo.patron.command.main");
		Vehiculo vehiculo1 = new Vehiculo("A01", 1, 1000.0);
		Vehiculo vehiculo2 = new Vehiculo("A011", 6, 2000.0);
		Vehiculo vehiculo3 = new Vehiculo("Z03", 2, 3000.0);
		Catalogo catalogo = new Catalogo();
		catalogo.agregar(vehiculo1);
		catalogo.agregar(vehiculo2);
		catalogo.agregar(vehiculo3);
		System.out.println("Visualizacion inicial del catalogo.");
		catalogo.visualizar();
		System.out.println("*******************************************");
		SolicitudRebaja solicitudRebaja = new SolicitudRebaja(10, 5, 0.1);
		catalogo.ejecutarSolicitudedRebaja(solicitudRebaja);
		System.out.println("Visualizacion del catalogo tras ejecutar la primera solicitud.");
		catalogo.visualizar();
		System.out.println("********************************************");
		SolicitudRebaja solicitudRebaja1 = new SolicitudRebaja(10, 5, 0.5);
		catalogo.ejecutarSolicitudedRebaja(solicitudRebaja1);
		System.out.println("Visualizacion del catalogo tras ejecutar la segunda solicitud.");
		catalogo.visualizar();
		catalogo.anularSolicitudRebaja(1);
		System.out.println("Visualizacion del catalogo tras anular la primera solicitud.");
		catalogo.visualizar();
		System.out.println("*********************************************");
		catalogo.restablecerSolicitudesRebaja(1);
		System.out.println("Visualizacion del catalogo tras restablecer la primera solicitud.");
		catalogo.visualizar();
		System.out.println("********************************************************************");
		System.out.println("********************** com.ejemplo.patron.command.main *******************");	
		
	}
	

}
