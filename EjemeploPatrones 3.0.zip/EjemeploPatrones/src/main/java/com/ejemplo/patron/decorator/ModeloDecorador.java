package com.ejemplo.patron.decorator;

public class ModeloDecorador extends Decorador{

	public ModeloDecorador(ComponenteGraficoVehiculo componente) {
		super(componente);
	}
	
	public void visualizacionInformacionTecnica(){
		System.out.println("Informacion Tecnica del modelo.");
	}
	
	public void visualizar(){
		super.visualizar();
		this.visualizacionInformacionTecnica();
	}
	
}
