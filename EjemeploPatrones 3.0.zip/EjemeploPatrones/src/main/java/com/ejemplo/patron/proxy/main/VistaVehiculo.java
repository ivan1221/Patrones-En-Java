package com.ejemplo.patron.proxy.main;

import com.ejemplo.patron.proxy.Animacion;
import com.ejemplo.patron.proxy.AnimacionProxy;

public class VistaVehiculo {

	public static void main(String[] args) {
		System.out.println("---*BEGIN *com.ejemplo.patron.proxy.main*-----------");
		Animacion animacion = new AnimacionProxy();
		animacion.dibuja();
		animacion.click();
		animacion.dibuja();
	}

}
