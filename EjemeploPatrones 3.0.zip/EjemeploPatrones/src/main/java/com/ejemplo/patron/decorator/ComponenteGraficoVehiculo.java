package com.ejemplo.patron.decorator;

public interface ComponenteGraficoVehiculo {
	
	void visualizar();

}
