package com.ejemplo.patron.proxy;

public interface Animacion {
	
	void dibuja();
	
	void click();

}
