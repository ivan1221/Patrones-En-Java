package com.ejemplo.patron.chainofresponsibility.main;

import com.ejemplo.patron.chainofresponsibility.Marca;
import com.ejemplo.patron.chainofresponsibility.Modelo;
import com.ejemplo.patron.chainofresponsibility.ObjetoBasico;
import com.ejemplo.patron.chainofresponsibility.Vehiculo;

public class Usuario {
	
	
	public static void main(String args[]){
		System.out.println("------------- BEGIN *com.ejemplo.patron.chainofresponsibility.main* --------------");
		ObjetoBasico vehiculo1 = new Vehiculo("Auto++ KT500 vehiculo de ocasion en buen estado");
		System.out.println(vehiculo1.devuelveDescripcion());
		ObjetoBasico modelo1 = new Modelo("KT400","Vehiculo amplio y confortable");
		ObjetoBasico vehiculo2 = new Vehiculo(null);
		vehiculo2.setSiguiente(modelo1);
		System.out.println(vehiculo2.devuelveDescripcion());
		ObjetoBasico marca1 = new Marca("de gran calidad","Marca del automovil", "Auto++");
		ObjetoBasico modelo2 = new Modelo("KT700",null);
		modelo2.setSiguiente(marca1);
		ObjetoBasico vehiculo3 = new Vehiculo(null);
		vehiculo3.setSiguiente(modelo2);
		System.out.println(vehiculo3.devuelveDescripcion());
		ObjetoBasico vehiculo4 = new Vehiculo(null);
		System.out.println(vehiculo4.devuelveDescripcion());
		System.out.println("------------- END *com.ejemplo.patron.chainofresponsibility.main* --------------");
		
	}

}
