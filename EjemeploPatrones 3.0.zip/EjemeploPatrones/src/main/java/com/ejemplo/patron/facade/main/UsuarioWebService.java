package com.ejemplo.patron.facade.main;

import java.util.List;

import com.ejemplo.patron.facade.WebServiceAuto;
import com.ejemplo.patron.facade.WebServiceAutoImpl;

public class UsuarioWebService {
	
	public static void main(String[] args) {
		System.out.println("com.ejemplo.patron.facade.main");
		WebServiceAuto webService = new WebServiceAutoImpl();
		System.out.println(webService.documento(0));
		System.out.println(webService.documento(1));
		List<String> resultado = webService.buscarVehiculos(6000, 1000);
		if (resultado.size() >0) {
			System.out.println("Vehiculo cuyo esta comprendido entre 500 y 7000");
			for (String string : resultado) {
			 System.out.println("*--* : "+ string);	
			}
		}
	}

}
