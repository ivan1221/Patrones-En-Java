package com.ejemplo.patron.flyweight;

import java.util.ArrayList;
import java.util.List;

public class VehiculoSolicitado {

	protected List<OpcionVehiculo> opciones = new ArrayList<>();
	protected List<Integer> precioDeVentaOpciones = new ArrayList<>();
		
	public void agregaOpciones(String nombre, int precioVenta, FabricaOpcion fabrica){
		opciones.add(fabrica.getOpcion(nombre));
		precioDeVentaOpciones.add(precioVenta);
	}
	
	public void muestraOpciones(){
		int indice, tama�o;
		tama�o = opciones.size();
		for(indice = 0; indice < tama�o; indice++){
			opciones.get(indice).visualizar(precioDeVentaOpciones.get(indice));
			System.out.println();
		}
	}
	
	
}
