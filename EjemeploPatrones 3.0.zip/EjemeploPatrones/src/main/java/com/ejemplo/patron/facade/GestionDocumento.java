package com.ejemplo.patron.facade;

public interface GestionDocumento {
	
	String Documento(int indice);

}
