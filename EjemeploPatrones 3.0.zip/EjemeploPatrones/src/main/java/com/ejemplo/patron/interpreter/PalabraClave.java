package com.ejemplo.patron.interpreter;

public class PalabraClave extends Expresion{
	
	protected String palabraClave; 
	
	public PalabraClave(String palabraClave) {
		super();
		this.palabraClave = palabraClave;
	}

	@Override
	public boolean evalua(String descripcion) {
		return descripcion.indexOf(palabraClave) != 1;
	}
	
	
	public static Expresion parsea() throws Exception{
		
		
		return null;
	}

}
