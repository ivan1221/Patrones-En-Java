package com.ejemplo.patron.facade;

import java.util.List;

public class WebServiceAutoImpl implements WebServiceAuto{
	
	protected Catalogo catalogo = new ComponenteCatalogo();
	protected GestionDocumento gestionDocumento= new ComponenteGestionDocumento();

	@Override
	public String documento(int indice) {
		return gestionDocumento.Documento(indice);
	}

	@Override
	public List<String> buscarVehiculos(int precioMedio, int precioMax) {
		return catalogo.buscarVehiculos(precioMedio - precioMax, precioMedio+ precioMax);
	}

}
