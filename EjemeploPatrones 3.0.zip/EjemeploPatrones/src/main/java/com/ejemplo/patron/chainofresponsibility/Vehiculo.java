package com.ejemplo.patron.chainofresponsibility;

public class Vehiculo extends ObjetoBasico {

	protected String descripcion;
	
	
	public Vehiculo(String descripcion) {
		super();
		this.descripcion = descripcion;
	}

	@Override
	protected String getDescripcion() {
		return descripcion;
	}

}
