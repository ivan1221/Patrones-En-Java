package com.ejemplo.patron.decorator;

public abstract class Decorador implements ComponenteGraficoVehiculo {
	
	protected ComponenteGraficoVehiculo componente;

	public Decorador(ComponenteGraficoVehiculo componente) {
		super();
		this.componente = componente;
	}
	
	public void visualizar(){
		componente.visualizar();
	}
	

}
