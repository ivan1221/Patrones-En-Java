package com.ejemplo.patron.flyweight.main;

import com.ejemplo.patron.flyweight.FabricaOpcion;
import com.ejemplo.patron.flyweight.VehiculoSolicitado;

public class Cliente {
	
	public static void main(String args[]){
		
		System.out.println("------* BEGIN * com.ejemplo.patron.flyweight.main*---------");
		FabricaOpcion fabrica = new FabricaOpcion();
		VehiculoSolicitado vehiculo = new VehiculoSolicitado();
		vehiculo.agregaOpciones("air bag",80, fabrica);
		vehiculo.agregaOpciones("direccion asistida", 90, fabrica);
		vehiculo.agregaOpciones("elevalunas electricos", 85, fabrica);
		vehiculo.muestraOpciones();
		System.out.println("----------* END * com.ejemplo.patron.flyweight.main ----------------------*");
	}
	

}
