package com.ejemplo.patron.facade;

import java.util.List;

public interface WebServiceAuto {
	
	String documento(int indice);
	
	List<String> buscarVehiculos(int precioMedio, int precioMax);

}
