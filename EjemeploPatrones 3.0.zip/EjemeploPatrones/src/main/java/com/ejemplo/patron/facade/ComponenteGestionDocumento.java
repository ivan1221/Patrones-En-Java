package com.ejemplo.patron.facade;

public class ComponenteGestionDocumento implements GestionDocumento{

	@Override
	public String Documento(int indice) {
		return "Documento numero "+indice;
	}

}
