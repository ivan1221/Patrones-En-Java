package com.ejemplo.patron.command;

import java.util.ArrayList;
import java.util.List;

public class Catalogo {
	
	protected List<Vehiculo> vehiculoEnStock = new ArrayList<>();
	protected List<SolicitudRebaja> solicitudes = new ArrayList<>();
	
	public void ejecutarSolicitudedRebaja(SolicitudRebaja solicitud){
		solicitudes.add(0, solicitud);
		solicitud.rebaja(vehiculoEnStock);
	}
	
	public void anularSolicitudRebaja(int orden){
		solicitudes.get(orden).anula();
	}
	
	public void restablecerSolicitudesRebaja(int orden){
		solicitudes.get(orden).restablece();
	}
	
	public void agregar(Vehiculo vehiculo){
		vehiculoEnStock.add(vehiculo);
	}
	
	public void visualizar() {
		for (Vehiculo vehiculo : vehiculoEnStock) {
			vehiculo.visualiza();
		}
	}

}
